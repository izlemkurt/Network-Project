﻿namespace Microsoft.VisualBasic
{
    internal class FileIO
    {
        public static object FileSystem { get; internal set; }
    }
}